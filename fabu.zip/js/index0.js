user = JSON.parse(user);
$("#greeting").html('您好：' + user.name);
